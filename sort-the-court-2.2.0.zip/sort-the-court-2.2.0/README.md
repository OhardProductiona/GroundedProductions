# sort-the-court [v2.2.0]
an epic game made by: [graebor](https://graebor.itch.io/sort-the-court), and re-uploaded by: [vocalnutria9174](https://github.com/VocalNutria9174/)

I gotten the code from the itch.io pc app when i downloaded the html5 version of the game.

pls support the creators of the game, i didn't make/help make the game in any way!!!

### download the game: https://github.com/VocalNutria9174/sort-the-court/releases/
i will update the game almost every time the devs update the game =]

### play the live game/demo here: https://tiny.one/sortthecourtgh9174

enjoy the game bois.
[remade by vocalnutria9174]
<3
